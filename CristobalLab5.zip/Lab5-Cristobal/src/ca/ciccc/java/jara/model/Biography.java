package ca.ciccc.java.jara.model;

/**
 * 
 * @author jara We create new class Biography that extends Book
 */
public final class Biography extends Book {
	/**
	 * 
	 * @param firstName
	 *            will set up the setting for first name
	 * @param lastName
	 *            will set up the setting for last name
	 * @param title
	 *            will set up the string for the title
	 * @param year
	 *            will set up the integer for year
	 * @throws InvalidArgumentException
	 *             when we set up the biography class
	 * @throws InvalidBookDateException
	 *             when we set up the biography class
	 */
	public Biography(Name firstName, Name lastName, String title, int year)
			throws InvalidArgumentException, InvalidBookDateException {
		super(firstName, lastName, title, year);

	}

	/**
	 * 
	 * We define Name subject
	 */
	private Name subject;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((subject == null) ? 0 : subject.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof Biography)) {
			return false;
		}
		Biography other = (Biography) obj;
		if (subject == null) {
			if (other.subject != null) {
				return false;
			}
		} else if (!subject.equals(other.subject)) {
			return false;
		}
		return true;
	}

}
