package ca.ciccc.java.jara.model;

/**
 * 
 * @author jara We create an invalidbookdateexception class that
 *         extendsexception
 */
public class InvalidBookDateException extends Exception {
	/**
	 * 
	 * Generated serial version unique ID
	 */
	private static final long serialVersionUID = -731334432168138820L;

	/**
	 * We create a constructor for InvalidBookDateException
	 */
	public InvalidBookDateException() {

	}

	/**
	 * 
	 * it's calling the parent invalid date exception
	 * 
	 * @param message
	 *            is the text explaining the invaliddateexception
	 */
	public InvalidBookDateException(String message) {
		super(message);

	}

	/**
	 * it'a calling the parent invalid date exception cause
	 * 
	 * @param cause
	 *            is the text explaining the InvalidArgumentException with the
	 *            Throwable process
	 */
	public InvalidBookDateException(Throwable cause) {
		super(cause);

	}

	/**
	 * it's calling the parent invalid date exception
	 * 
	 * @param message
	 *            is the text explaining the invaliddateexception
	 * @param cause
	 *            the name of the exception
	 */
	public InvalidBookDateException(String message, Throwable cause) {
		super(message, cause);

	}

	/**
	 * We define parameters message, cause, enableSuppression and writableStackTrace
	 * for InvalidDateException
	 * 
	 * @param message for InvalidBookDateException
	 * @param cause for InvalidBookDateException
	 * @param enableSuppression for InvalidBookDateException
	 * @param writableStackTrace for InvalidBookDateException
	 */
	public InvalidBookDateException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);

	}

}
