package ca.ciccc.java.jara.model;

import java.util.ArrayList;
import java.util.Collections;

/**
 * 
 * @author jara We create Bookstore class
 */
public class Bookstore {
	ArrayList<Book> books;

	/**
	 * 
	 * We define constructor for Bookstore
	 */
	public Bookstore() {
		/**
		 * We define new arraylist Book
		 * 
		 */
		books = new ArrayList<Book>();

	}

	/**
	 * 
	 * @param firstName
	 *            will set up the setting for first name
	 * @param lastName
	 *            will set up the setting for last name
	 * @param title
	 *            will set up the string for the title
	 * @param year
	 *            will set up the integer for year
	 */
	public void addBook(Name firstName, Name lastName, String title, int year) {
		try {
			books.add(new Book(firstName, lastName, title, year));
		} catch (InvalidArgumentException e) {
			System.out.println(e.getMessage());
		} catch (InvalidBookDateException e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * 
	 * We define the print process to sort the list of books with and without sort
	 */
	public void displayBooks() {
		System.out.println("books before sorting");
		for (Book book : books) {
			System.out.println(book);
		}
		System.out.println("books after sort");
		Collections.sort(books);
		for (Book book : books) {
			System.out.println(book);
		}
	}
}
