package ca.ciccc.java.jara.model;

/**
 * 
 * @author jara We create an invalidargumentexception class that extends
 *         exception
 */
public class InvalidArgumentException extends Exception {
	/**
	 * 
	 * Generated serial version unique ID
	 */
	private static final long serialVersionUID = -6972476586624634109L;

	/**
	 * We create a constructor for InvalidArgumentException
	 */
	public InvalidArgumentException() {

	}

	/**
	 * 
	 * it's calling the parent invalid argument exception
	 * 
	 * @param message
	 *            is the text explaining the invalidargumentexception
	 */
	public InvalidArgumentException(String message) {
		super(message);
	}

	/**
	 * it'a calling the parent invalid argument exception cause
	 * 
	 * @param cause
	 *            is the text explaining the InvalidArgumentException with the
	 *            Throwable process
	 */
	public InvalidArgumentException(Throwable cause) {
		super(cause);
	}

	/**
	 *  it's calling the parent invalid argument exception
	 * @param message
	 *  is the text explaining the invalidargumentexception
	 * @param cause the name of the exception
	 */
	public InvalidArgumentException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * We define parameters message, cause, enableSuppression and writableStackTrace
	 * for InvalidArgumentException
	 * 
	 * @param message for InvalidArgumentException
	 * @param cause for InvalidArgumentException
	 * @param enableSuppression for InvalidArgumentException
	 * @param writableStackTrace for InvalidArgumentException
	 */
	public InvalidArgumentException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
