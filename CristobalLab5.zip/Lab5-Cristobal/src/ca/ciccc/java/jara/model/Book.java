package ca.ciccc.java.jara.model;

/**
 * 
 * 
 * @author jara
 *
 *         We define Book class that implements Comparable Book
 */
public class Book implements Comparable<Book> {
	/**
	 * 
	 * We define the instance variable firstName, lastName, title, year
	 */
	private Name firstName;
	private Name lastName;
	private String title;
	private int year;

	/**
	 * 
	 * @param firstName
	 *            we set first name
	 * @param lastName
	 *            we set last name
	 * @param title
	 *            we set title
	 * @param year
	 *            we set year
	 * @throws InvalidArgumentException
	 *             we throw an invalid argument exception
	 * @throws InvalidBookDateException
	 *             we throw an invalid book date exception
	 */
	public Book(Name firstName, Name lastName, String title, int year)
			throws InvalidArgumentException, InvalidBookDateException {
		setFirstName(firstName);
		setLastName(lastName);
		setTitle(title);
		setYear(year);
	}

	/**
	 * setting the getter to return first name
	 * 
	 * @return firstName as getter
	 */
	public final Name getFirstName() {
		return firstName;
	}

	/**
	 * 
	 * @param firstName
	 *            define the condition when can not be null or empty
	 * @throws InvalidArgumentException
	 *             when we have the previous condition for firstname
	 */
	public final void setFirstName(Name firstName) throws InvalidArgumentException {

		if (firstName == null || firstName.isEmpty()) {
			throw new InvalidArgumentException("firstName cannot be null or empty");
		} else {
			this.firstName = firstName;
		}
	}

	/**
	 * setting the getter to return last name
	 * 
	 * @return lastName as getter
	 */
	public final Name getLastName() {
		return lastName;
	}

	/**
	 * 
	 * @param lastName
	 *            define the condition when can not be null or empty
	 * @throws InvalidArgumentException
	 *             if their parameter is null or an empty string
	 */
	public final void setLastName(Name lastName) throws InvalidArgumentException {
		this.lastName = lastName;
		if (lastName == null || lastName.isEmpty()) {

		}
	}

	/**
	 * title when we set the getter
	 * 
	 * @return title as getter
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * we define setter for title
	 * 
	 * @param title
	 *            defined as setter
	 */
	public final void setTitle(String title) {
		this.title = title;
	}

	/**
	 * We set getter for year
	 * 
	 * @return year as getter
	 */
	public final int getYear() {
		return year;
	}

	/**
	 * 
	 * @param year
	 *            will be returned with the exception that year cannot be greater
	 *            then 2017
	 * @throws InvalidBookDateException
	 *             will be throw to define this if condition
	 */
	public final void setYear(int year) throws InvalidBookDateException {
		if (year > 2017) {
			throw new InvalidBookDateException("Year cannot be greater than 2017");
		} else {
			this.year = year;
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + year;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		// Compare reference
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		// Check if obj is really a Book object
		if (!(obj instanceof Book)) {
			return false;
		}

		// Cast
		Book other = (Book) obj;
		if (title == null) {
			if (other.title != null) {
				return false;
			}
		} else if (!title.equals(other.title)) {
			return false;
		}

		if (year != other.year) {
			return false;
		}

		return true;
	}

	@Override
	public int compareTo(Book o) {
		if (this.year < o.year) {
			return 1;
		}

		if (this.year > o.year) {
			return -1;
		}

		return 0;
	}

	@Override
	public String toString() {
		return "Book [firstName=" + firstName + ", lastName=" + lastName + ", title=" + title + ", year=" + year + "]";
	}
}
