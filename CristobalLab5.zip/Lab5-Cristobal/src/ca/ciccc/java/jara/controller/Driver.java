
package ca.ciccc.java.jara.controller;

import ca.ciccc.java.jara.model.Bookstore;
import ca.ciccc.java.jara.model.Name;

public class Driver {

	public static void main(String[] args) {
		Bookstore bs = new Bookstore();

		Name firstName1 = new Name();
		Name lastName1 = new Name();
		lastName1.setName("Smith");
		firstName1.setName("John");
		lastName1.setName("Smith");
		bs.addBook(firstName1, lastName1, "Java developers", 1896);

		Name firstName2 = new Name();
		Name lastName2 = new Name();
		lastName2.setName("Jordan");
		firstName2.setName("Michael");
		lastName2.setName("Jordan");
		bs.addBook(firstName2, lastName2, "Java for begginers", 1999);

		Name firstName3 = new Name();
		Name lastName3 = new Name();
		lastName3.setName("Sawyer");
		firstName3.setName("Rachel");
		lastName3.setName("Sawyer");
		bs.addBook(firstName3, lastName3, "Java is not javascript", 1995);

		Name firstName4 = new Name();
		Name lastName4 = new Name();
		lastName4.setName("Robinson");
		firstName4.setName("Silvia");
		lastName4.setName("Robinson");
		bs.addBook(firstName4, lastName4, "Java is not death", 1996);

		Name firstName5 = new Name();
		Name lastName5 = new Name();
		lastName5.setName("Cruise");
		firstName5.setName("Arthur");
		lastName5.setName("Cruise");
		bs.addBook(firstName5, lastName5, "Java needs you", 2003);

		bs.displayBooks();
	}
}
